export const sampleHostels = [
  {
    id: 'h1', name: 'Green Nest Student Residency', city: 'Hyderabad',
    area: 'Madhapur', address: 'Near Metro Station, Madhapur, Hyderabad',
    rent: 8500, roomType: 'Sharing', gender: 'Any', available: true,
    rating: 4.7, beds: 2, description: 'A comfortable, student-friendly stay with study areas and daily housekeeping.',
    facilities: ['Wi-Fi', 'Meals', 'Laundry', 'CCTV', 'Study Room'],
    image: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=1000'
  },
  {
    id: 'h2', name: 'Urban Stay PG', city: 'Hyderabad',
    area: 'Kukatpally', address: 'KPHB Phase 6, Kukatpally, Hyderabad',
    rent: 6500, roomType: 'Sharing', gender: 'Male', available: true,
    rating: 4.4, beds: 3, description: 'Affordable accommodation with easy access to public transport and shops.',
    facilities: ['Wi-Fi', 'Meals', 'Power Backup', 'CCTV'],
    image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=1000'
  },
  {
    id: 'h3', name: 'Comfort Corner Ladies Hostel', city: 'Warangal',
    area: 'Hanamkonda', address: 'Main Road, Hanamkonda, Warangal',
    rent: 7200, roomType: 'Sharing', gender: 'Female', available: true,
    rating: 4.8, beds: 2, description: 'A welcoming hostel with secure entry, dining space, and quiet common areas.',
    facilities: ['Wi-Fi', 'Meals', 'Laundry', 'CCTV', 'Hot Water'],
    image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=1000'
  },
  {
    id: 'h4', name: 'Metro View Private Rooms', city: 'Hyderabad',
    area: 'Ameerpet', address: 'Near Ameerpet Metro, Hyderabad',
    rent: 12000, roomType: 'Private', gender: 'Any', available: true,
    rating: 4.5, beds: 1, description: 'Private rooms for students and working professionals.',
    facilities: ['Wi-Fi', 'Power Backup', 'Laundry', 'Parking'],
    image: 'https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1000'
  }
]
