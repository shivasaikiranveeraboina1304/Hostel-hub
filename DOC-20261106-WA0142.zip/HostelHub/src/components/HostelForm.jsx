import { useEffect, useState } from 'react'
import { X } from 'lucide-react'
const empty = { name:'', city:'', area:'', address:'', rent:'', roomType:'Sharing', gender:'Any', beds:1, available:true, rating:4.5, description:'', facilities:[], image:'' }
const options = ['Wi-Fi','Meals','Laundry','CCTV','Study Room','Power Backup','Hot Water','Parking']
export default function HostelForm({ initial, onSave, onClose }) {
  const [form, setForm] = useState(empty)
  useEffect(() => setForm(initial ? { ...empty, ...initial, rent:String(initial.rent) } : empty), [initial])
  const update = (key, value) => setForm(f => ({ ...f, [key]: value }))
  const toggle = item => update('facilities', form.facilities.includes(item) ? form.facilities.filter(x => x !== item) : [...form.facilities, item])
  function submit(e) {
    e.preventDefault()
    onSave({ ...form, rent:Number(form.rent), beds:Number(form.beds), rating:Number(form.rating), image:form.image || 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=1000' })
  }
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}><form className="modal form-modal" onSubmit={submit}>
    <div className="modal-head"><div><p className="eyebrow">HOSTEL LISTING</p><h2>{initial ? 'Edit hostel' : 'Add a hostel'}</h2></div><button type="button" className="icon-button" onClick={onClose}><X /></button></div>
    <div className="form-grid">
      <label>Hostel name<input required value={form.name} onChange={e=>update('name',e.target.value)} /></label>
      <label>City<input required value={form.city} onChange={e=>update('city',e.target.value)} /></label>
      <label>Area / locality<input required value={form.area} onChange={e=>update('area',e.target.value)} /></label>
      <label>Monthly rent (₹)<input required type="number" min="1" value={form.rent} onChange={e=>update('rent',e.target.value)} /></label>
      <label className="wide">Full address<input required value={form.address} onChange={e=>update('address',e.target.value)} /></label>
      <label>Room type<select value={form.roomType} onChange={e=>update('roomType',e.target.value)}><option>Sharing</option><option>Private</option></select></label>
      <label>Suitable for<select value={form.gender} onChange={e=>update('gender',e.target.value)}><option>Any</option><option>Male</option><option>Female</option></select></label>
      <label className="wide">Photo URL<input value={form.image} onChange={e=>update('image',e.target.value)} placeholder="Paste a publicly accessible image URL" /></label>
      <label className="wide">Description<textarea rows="3" value={form.description} onChange={e=>update('description',e.target.value)} /></label>
      <div className="wide"><span className="field-label">Facilities</span><div className="check-grid">{options.map(x=><label className="check" key={x}><input type="checkbox" checked={form.facilities.includes(x)} onChange={()=>toggle(x)} />{x}</label>)}</div></div>
      <label className="check wide"><input type="checkbox" checked={form.available} onChange={e=>update('available',e.target.checked)} /> Beds are currently available</label>
    </div>
    <div className="modal-actions"><button type="button" className="button secondary" onClick={onClose}>Cancel</button><button className="button primary">Save listing</button></div>
  </form></div>
}
