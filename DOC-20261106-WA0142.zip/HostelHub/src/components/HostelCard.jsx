import { MapPin, Star, ArrowUpRight } from 'lucide-react'

export default function HostelCard({ hostel, onOpen }) {
  return <article className="hostel-card">
    <button className="image-button" onClick={() => onOpen(hostel)} aria-label={`View ${hostel.name}`}>
      <img src={hostel.image} alt={hostel.name} />
      <span className="image-tag">{hostel.available ? 'Beds available' : 'Currently full'}</span>
    </button>
    <div className="card-content">
      <div className="card-title-row"><h3>{hostel.name}</h3><span className="rating"><Star size={14} fill="currentColor" /> {hostel.rating || 'New'}</span></div>
      <p className="muted location"><MapPin size={15} /> {hostel.area}, {hostel.city}</p>
      <div className="chips">{(hostel.facilities || []).slice(0, 3).map(f => <span key={f}>{f}</span>)}</div>
      <div className="card-bottom"><div><strong>₹{Number(hostel.rent).toLocaleString('en-IN')}</strong><small> / month</small></div><button className="text-button" onClick={() => onOpen(hostel)}>View details <ArrowUpRight size={16} /></button></div>
    </div>
  </article>
}
