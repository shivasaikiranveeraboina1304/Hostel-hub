import { useEffect, useMemo, useState } from 'react'
import { Search, MapPin, SlidersHorizontal, ShieldCheck, Home, Menu, X, ArrowRight, Users, Building2, Heart, Mail, Phone, LogOut, Plus, Pencil, Trash2, Eye, CheckCircle2 } from 'lucide-react'
import HostelCard from './components/HostelCard'
import HostelForm from './components/HostelForm'
import { getHostels, saveHostel, removeHostel, saveEnquiry, getEnquiries } from './lib/store'
import { firebaseEnabled, auth, db } from './lib/firebase'
import { signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth'
import { doc, getDoc } from 'firebase/firestore'

const DEMO_EMAIL = 'admin@hostelhub.demo'
const DEMO_PASSWORD = 'HostelHub123!'

export default function App() {
  const [hostels, setHostels] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [city, setCity] = useState('')
  const [maxRent, setMaxRent] = useState('20000')
  const [roomType, setRoomType] = useState('Any')
  const [gender, setGender] = useState('Any')
  const [facility, setFacility] = useState('')
  const [selected, setSelected] = useState(null)
  const [page, setPage] = useState('home')
  const [admin, setAdmin] = useState(false)
  const [adminEmail, setAdminEmail] = useState('')
  const [adminPassword, setAdminPassword] = useState('')
  const [loginError, setLoginError] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [enquiries, setEnquiries] = useState([])
  const [toast, setToast] = useState('')
  const [mobileMenu, setMobileMenu] = useState(false)
  const [enquiryForm, setEnquiryForm] = useState({ name:'', phone:'', email:'', message:'' })

  async function refresh() {
    setLoading(true)
    try { setHostels(await getHostels()) } catch (e) { console.error(e); notify('Could not load listings. Check Firebase setup.') }
    setLoading(false)
  }
  useEffect(() => { refresh() }, [])
  useEffect(() => {
    if (!firebaseEnabled) return
    return onAuthStateChanged(auth, async user => {
      if (!user) { setAdmin(false); return }
      const snap = await getDoc(doc(db, 'users', user.uid))
      setAdmin(snap.exists() && snap.data().role === 'admin')
    })
  }, [])
  function notify(message) { setToast(message); window.setTimeout(() => setToast(''), 3000) }

  const filtered = useMemo(() => hostels.filter(h => {
    const term = search.toLowerCase()
    const matchesText = !term || `${h.name} ${h.city} ${h.area} ${h.address}`.toLowerCase().includes(term)
    return matchesText && (!city || h.city.toLowerCase() === city.toLowerCase()) &&
      Number(h.rent) <= Number(maxRent || 999999) &&
      (roomType === 'Any' || h.roomType === roomType) &&
      (gender === 'Any' || h.gender === 'Any' || h.gender === gender) &&
      (!facility || (h.facilities || []).includes(facility))
  }), [hostels, search, city, maxRent, roomType, gender, facility])
  const cities = [...new Set(hostels.map(h => h.city).filter(Boolean))]

  async function login(e) {
    e.preventDefault(); setLoginError('')
    try {
      if (firebaseEnabled) {
        await signInWithEmailAndPassword(auth, adminEmail, adminPassword)
      } else if (adminEmail === DEMO_EMAIL && adminPassword === DEMO_PASSWORD) {
        setAdmin(true); setPage('admin'); setAdminPassword(''); return
      } else throw new Error('Incorrect demo email or password.')
      setPage('admin')
    } catch (err) { setLoginError(err.message || 'Sign in failed. Check your details.') }
  }
  async function logout() {
    if (firebaseEnabled) await signOut(auth)
    setAdmin(false); setPage('home'); notify('You have signed out.')
  }
  async function saveListing(data) {
    try {
      await saveHostel(data); await refresh(); setFormOpen(false); setEditing(null); notify('Hostel listing saved.')
    } catch (e) { notify('Unable to save. Check admin permissions and Firebase rules.') }
  }
  async function deleteListing(id) {
    if (!window.confirm('Delete this hostel listing?')) return
    try { await removeHostel(id); await refresh(); notify('Listing deleted.') } catch { notify('Unable to delete listing.') }
  }
  async function openEnquiries() {
    try { setEnquiries(await getEnquiries()) } catch { setEnquiries([]) }
  }
  async function submitEnquiry(e) {
    e.preventDefault()
    try {
      await saveEnquiry({ ...enquiryForm, hostelId:selected.id, hostelName:selected.name })
      setEnquiryForm({ name:'', phone:'', email:'', message:'' }); notify('Your enquiry has been sent! The hostel owner can contact you.')
    } catch { notify('Could not send enquiry. Please try again.') }
  }
  function navigate(target) { setPage(target); setSelected(null); setMobileMenu(false); if (target === 'enquiries') openEnquiries(); window.scrollTo(0,0) }

  return <div className="app-shell">
    <header className="topbar"><a className="brand" href="#" onClick={e=>{e.preventDefault();navigate('home')}}><span className="brand-mark"><Home size={21}/></span><span>Hostel<span className="brand-accent">Hub</span><small>FIND YOUR PLACE</small></span></a>
      <nav className={mobileMenu?'nav open':'nav'}><button onClick={()=>navigate('home')}>Explore hostels</button><a href="#how" onClick={()=>navigate('home')}>How it works</a><button onClick={()=>navigate('adminLogin')} className="admin-link"><ShieldCheck size={16}/> Admin</button></nav>
      <button className="mobile-toggle" onClick={()=>setMobileMenu(!mobileMenu)} aria-label="Toggle menu">{mobileMenu?<X/>:<Menu/>}</button>
    </header>

    {page === 'home' && <>
      <section className="hero"><div className="hero-inner"><div className="hero-copy"><span className="eyebrow light">A BETTER WAY TO FIND YOUR STAY</span><h1>Your next place<br/>to call <em>home.</em></h1><p>Discover hostels and PGs that fit your location, lifestyle, and monthly budget.</p><div className="hero-stats"><span><Building2/> <b>{hostels.length}+</b> listings</span><span><Users/> For students & professionals</span></div></div><div className="hero-art"><div className="hero-photo"><img src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=1100" alt="Bright comfortable room"/></div><div className="floating-note"><span className="note-icon"><CheckCircle2/></span><span><b>Find your fit</b><small>Compare stays with ease</small></span></div></div></div>
        <div className="search-panel"><div className="search-field"><MapPin/><label>Location<input value={search} onChange={e=>setSearch(e.target.value)} placeholder="City, area or hostel name"/></label></div><div className="search-field"><span className="rupee">₹</span><label>Maximum monthly rent<select value={maxRent} onChange={e=>setMaxRent(e.target.value)}><option value="5000">Up to ₹5,000</option><option value="8000">Up to ₹8,000</option><option value="12000">Up to ₹12,000</option><option value="15000">Up to ₹15,000</option><option value="20000">Up to ₹20,000</option><option value="50000">Any budget</option></select></label></div><button className="button primary search-button" onClick={()=>document.getElementById('listings').scrollIntoView({behavior:'smooth'})}><Search size={18}/> Find a hostel</button></div>
      </section>
      <main className="main-content" id="listings"><div className="section-heading"><div><p className="eyebrow">EXPLORE STAYS</p><h2>Find a place that fits</h2><p className="muted">Browse verified-style listings and compare what matters to you.</p></div><span className="result-count">{filtered.length} places found</span></div>
        <div className="filter-bar"><label><SlidersHorizontal size={17}/> Filters</label><select value={city} onChange={e=>setCity(e.target.value)}><option value="">All cities</option>{cities.map(c=><option key={c}>{c}</option>)}</select><select value={roomType} onChange={e=>setRoomType(e.target.value)}><option>Any</option><option>Sharing</option><option>Private</option></select><select value={gender} onChange={e=>setGender(e.target.value)}><option>Any</option><option>Male</option><option>Female</option></select><select value={facility} onChange={e=>setFacility(e.target.value)}><option value="">Any facility</option>{['Wi-Fi','Meals','Laundry','CCTV','Study Room','Power Backup','Hot Water','Parking'].map(x=><option key={x}>{x}</option>)}</select><button className="clear-button" onClick={()=>{setSearch('');setCity('');setMaxRent('20000');setRoomType('Any');setGender('Any');setFacility('')}}>Clear all</button></div>
        {loading?<div className="empty-state">Loading hostel listings…</div>:filtered.length?<div className="hostel-grid">{filtered.map(h=><HostelCard key={h.id} hostel={h} onOpen={setSelected}/>)}</div>:<div className="empty-state"><Search size={30}/><h3>No hostels found</h3><p>Try changing your location or filters.</p></div>}
      </main>
      <section className="how-section" id="how"><p className="eyebrow">SIMPLE AS IT SHOULD BE</p><h2>Your stay, sorted in three steps</h2><div className="steps"><div><span>01</span><h3>Search your location</h3><p>Enter a city or area and set your monthly budget.</p></div><div><span>02</span><h3>Compare your options</h3><p>Check rent, room types, facilities, and photos.</p></div><div><span>03</span><h3>Send an enquiry</h3><p>Contact the listing team to ask about availability.</p></div></div></section>
    </>}

    {page === 'adminLogin' && <main className="auth-wrap"><form className="auth-card" onSubmit={login}><div className="auth-icon"><ShieldCheck/></div><p className="eyebrow">HOSTELHUB MANAGEMENT</p><h2>Admin sign in</h2><p className="muted">Sign in to manage hostel listings and enquiries.</p><label>Email address<input type="email" required value={adminEmail} onChange={e=>setAdminEmail(e.target.value)} placeholder="admin@example.com"/></label><label>Password<input type="password" required value={adminPassword} onChange={e=>setAdminPassword(e.target.value)} placeholder="Enter password"/></label>{!firebaseEnabled&&<div className="demo-hint"><b>Demo access</b><br/>admin@hostelhub.demo<br/>HostelHub123!</div>}{loginError&&<p className="error-text">{loginError}</p>}<button className="button primary full">Sign in to dashboard <ArrowRight size={17}/></button><button type="button" className="back-link" onClick={()=>navigate('home')}>Back to website</button></form></main>}

    {page === 'admin' && <main className="admin-main"><div className="admin-heading"><div><p className="eyebrow">HOSTELHUB MANAGEMENT</p><h1>Admin dashboard</h1><p className="muted">Manage accommodation listings and keep information up to date.</p></div><button className="button secondary" onClick={logout}><LogOut size={16}/> Sign out</button></div>{!admin?<div className="empty-state">Please sign in as an administrator.</div>:<><div className="admin-stats"><div><Building2/><span>Total listings</span><b>{hostels.length}</b></div><div><CheckCircle2/><span>Available listings</span><b>{hostels.filter(h=>h.available).length}</b></div><div><Mail/><span>Enquiries</span><b>{enquiries.length || '—'}</b></div></div><div className="admin-toolbar"><h2>Hostel listings</h2><div><button className="button secondary" onClick={()=>{openEnquiries();setPage('enquiries')}}><Mail size={16}/> View enquiries</button><button className="button primary" onClick={()=>{setEditing(null);setFormOpen(true)}}><Plus size={17}/> Add hostel</button></div></div><div className="table-wrap"><table><thead><tr><th>Hostel</th><th>Location</th><th>Monthly rent</th><th>Status</th><th>Actions</th></tr></thead><tbody>{hostels.map(h=><tr key={h.id}><td><div className="table-hostel"><img src={h.image} alt=""/><b>{h.name}</b></div></td><td>{h.area}, {h.city}</td><td>₹{Number(h.rent).toLocaleString('en-IN')}</td><td><span className={h.available?'status available':'status full'}>{h.available?'Available':'Full'}</span></td><td><div className="row-actions"><button title="View" onClick={()=>setSelected(h)}><Eye size={16}/></button><button title="Edit" onClick={()=>{setEditing(h);setFormOpen(true)}}><Pencil size={16}/></button><button title="Delete" onClick={()=>deleteListing(h.id)}><Trash2 size={16}/></button></div></td></tr>)}</tbody></table></div></>}</main>}

    {page === 'enquiries' && <main className="admin-main"><div className="admin-heading"><div><p className="eyebrow">HOSTELHUB MANAGEMENT</p><h1>Student enquiries</h1><p className="muted">Messages submitted through hostel listings.</p></div><button className="button secondary" onClick={()=>navigate('admin')}>Back to dashboard</button></div>{!admin?<div className="empty-state">Please sign in as an administrator.</div>:enquiries.length?<div className="enquiry-list">{enquiries.map(e=><article key={e.id}><b>{e.name}</b><span>{e.hostelName}</span><p>{e.message}</p><small>{e.email} · {e.phone}</small></article>)}</div>:<div className="empty-state">No enquiries have been received yet.</div>}</main>}

    {selected && <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&setSelected(null)}><div className="modal detail-modal"><button className="icon-button close-detail" onClick={()=>setSelected(null)}><X/></button><img className="detail-image" src={selected.image} alt={selected.name}/><div className="detail-body"><p className="eyebrow">HOSTEL DETAILS</p><h2>{selected.name}</h2><p className="muted location"><MapPin size={16}/>{selected.address}</p><div className="detail-price">₹{Number(selected.rent).toLocaleString('en-IN')} <small>/ month</small></div><p>{selected.description}</p><div className="detail-facts"><span>{selected.roomType} room</span><span>{selected.gender} accommodation</span><span>{selected.available?'Beds available':'Currently full'}</span></div><h3>Facilities</h3><div className="chips">{(selected.facilities||[]).map(f=><span key={f}>{f}</span>)}</div><hr/><h3>Send an enquiry</h3><form className="enquiry-form" onSubmit={submitEnquiry}><input required placeholder="Your name" value={enquiryForm.name} onChange={e=>setEnquiryForm({...enquiryForm,name:e.target.value})}/><input required type="tel" placeholder="Phone number" value={enquiryForm.phone} onChange={e=>setEnquiryForm({...enquiryForm,phone:e.target.value})}/><input type="email" placeholder="Email (optional)" value={enquiryForm.email} onChange={e=>setEnquiryForm({...enquiryForm,email:e.target.value})}/><textarea placeholder="Your message" value={enquiryForm.message} onChange={e=>setEnquiryForm({...enquiryForm,message:e.target.value})}/><button className="button primary full">Send enquiry <ArrowRight size={17}/></button></form></div></div></div>}
    {formOpen&&<HostelForm initial={editing} onSave={saveListing} onClose={()=>{setFormOpen(false);setEditing(null)}}/>}
    {toast&&<div className="toast"><CheckCircle2 size={17}/>{toast}</div>}
    <footer className="footer"><div className="brand footer-brand"><span className="brand-mark"><Home size={20}/></span><span>Hostel<span className="brand-accent">Hub</span><small>FIND YOUR PLACE</small></span></div><p>Making it easier to find a place that feels like home.</p><span>© {new Date().getFullYear()} HostelHub · College project demo</span></footer>
  </div>
}
