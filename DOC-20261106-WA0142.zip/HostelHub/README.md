# HostelHub — Hostel Finder

A responsive React + Vite starter project for finding hostels/PG accommodation. It includes student browsing and filtering, hostel detail views, enquiry submission, and an admin dashboard to add, edit, and remove listings.

## Run locally

1. Install **Node.js LTS**.
2. Extract this ZIP.
3. Open the extracted `HostelHub` folder in VS Code.
4. Open Terminal in VS Code and run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local address shown in the terminal (usually `http://localhost:5173`).

## Demo mode

The project works immediately in demo mode using browser `localStorage`; no Firebase setup is required to try the interface.

- Admin demo email: `admin@hostelhub.demo`
- Admin demo password: `HostelHub123!`

**Demo login is only for local demonstration.** It is not secure authentication and must not be used for a public deployment. Demo data is saved in the current browser only.

## Connect Firebase (optional)

1. Create a Firebase project at https://console.firebase.google.com/.
2. Add a Web App and copy its configuration.
3. Copy `.env.example` to `.env` and fill in the Firebase values.
4. In Firebase Console, enable **Authentication → Email/Password** and create your admin account.
5. Create a Firestore database.
6. Publish the rules in `firestore.rules`.
7. In Firestore, create a document in `users/{admin-uid}` with:
   ```json
   { "role": "admin", "name": "HostelHub Admin" }
   ```
8. Restart `npm run dev`.

When Firebase configuration is present, the app uses Firebase Authentication and Firestore. Without it, it uses local demo mode.

## Main features

- Search by city, locality, and hostel name.
- Filter by monthly rent, room type, gender preference, and facilities.
- Hostel cards with images, rent, address, facilities, and availability.
- Hostel detail view and enquiry form.
- Admin sign-in and dashboard.
- Add, edit, and delete hostel listings.
- Responsive layout for mobile and desktop.

## Project structure

```text
HostelHub/
├── src/
│   ├── components/
│   ├── data/
│   ├── lib/
│   ├── App.jsx
│   ├── main.jsx
│   └── styles.css
├── .env.example
├── firestore.rules
├── index.html
└── package.json
```

## Important before publishing

- Replace demo login with Firebase Authentication.
- Set the admin role securely in Firestore.
- Use Firebase Storage (or another trusted image host) for production image uploads.
- Review Firestore rules and privacy requirements.
- Never commit your `.env` file or share private credentials.
